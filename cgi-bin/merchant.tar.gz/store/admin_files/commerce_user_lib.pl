## This file contains the user specific variables
## necessary for merchant.cgi

$sc_gateway_name = "gateway";
$sc_sales_tax = ".0785";
$sc_sales_tax_state = "TX";
$sc_send_order_to_email = "yes";
$sc_order_log_name = "your_order.log";
$sc_send_order_to_log = "yes";
$sc_order_email = "sales\@merchant-store.com";
$sc_store_url = "http://www.merchantcgi.com/cgi-bin/store/merchant.cgi";
$sc_admin_email = "sales\@merchant-store.com";
$sc_domain_name_for_cookie = "www.merchantcgi.com";
$sc_path_for_cookie = "/cgi-bin/store";
$URL_of_images_directory = "http://www.merchantcgi.com/demo";
$colorcode = "#aabbdd";
$sc_db_max_rows_returned = "10";
$sc_user = "admin";
$sc_pass = "admin";
$sc_layout = "4";
1;
