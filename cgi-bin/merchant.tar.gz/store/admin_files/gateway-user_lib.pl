$sc_gateway_username = "23956";
$sc_order_script_url = "https://secure.paymentclearing.com/cgi-bin/mas/split.cgi";
$mername = "ABC Company";
$acceptcards = "1";
$acceptchecks = "0";
$accepteft = "1";
$altaddr = "1";
$email_text = "This is where text for the confirmation e-mail goes.";
1;
